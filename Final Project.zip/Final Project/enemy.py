
from pygame import *
from settings import *
from math import *
from shoot import Projectile

''' class description : 
    Initializes enemies with speed, health, resistance etc taken from settings.py. 
    contains methods such as shoot_projectile, that creates an instance of the Projectile class and shoots it in the direction
    of the player and try_move, which checks collisions with the other fairies before moving towards the player. 
    update() is rewritten to detect the direction the fairies should face, along with shield collision logic.
'''
class Enemy(sprite.Sprite):
    def __init__(self, pos, groups, type, path, player, obstacles):
        super().__init__(groups) #adds the sprite to the given groups. I dont have any hidden layers right now so all layers get added to obstacles and visible sprite groups
        self.obstacles = obstacles
        self.sprite_type = type #when creating the map, I gave each entity a certain class. enemy sprites under "enemy", gems under "collectible" etc
        self.current_sprite = 0.0
        self.enemy_type = path.split('\\')[3].split('.')[0]
        self.speed = enemy_data[self.enemy_type]['speed']
        self.health = enemy_data[self.enemy_type]['health']
        self.resistance = enemy_data[self.enemy_type]['resistance']
        self.attack_r = enemy_data[self.enemy_type]['attack_r']
        self.notice_r = enemy_data[self.enemy_type]['notice_r']
        self.damage = enemy_data[self.enemy_type]['damage']
        self.cooldown = enemy_data[self.enemy_type]['cooldown']
        self.status = 'idle'
        self.direction = math.Vector2()
        self.image = image.load(path)
        self.rect = self.image.get_rect(topleft = pos)
        self.mask = mask.from_surface(self.image)
        self.player = player #passing in an instance of the player to get its position and stuff
        self.attack_timer = 0
        self.last_hit = 0
        

    def load_sprite_sheet(self, path, frame_width, frame_height):
        sheet = image.load(path).convert_alpha()
        sw, sh = sheet.get_size()

        sprites = []
        for y in range(0, sh, frame_height):
            for x in range(0, sw, frame_width):
                frame = Surface((frame_width, frame_height), SRCALPHA)
                frame.blit(sheet, (0, 0), (x, y, frame_width, frame_height)) #blit different parts of the spritesheet 
                sprites.append(frame)

        return sprites
    
    def animate(self, dir):
        sheet = f"levels//level_1//tilesets//{self.enemy_type}_spritesheet.png"
        sprites = self.load_sprite_sheet(sheet, 32, 64)
        self.current_sprite += 0.15
        if self.current_sprite >= 3:
            self.current_sprite = 0
        if dir == 'right':
            self.image = sprites[int(self.current_sprite)]
        else:
            self.image = transform.flip(sprites[int(self.current_sprite)], True, False)
        self.mask = mask.from_surface(self.image)

    def move(self, direction):
        #vector subtraction. V = VB - VA
        old_rect = self.rect.copy()
        if direction.length() != 0:
            self.direction = direction.normalize()
        else:
            self.direction = math.Vector2(0, 0)
        
        self.trymove('h', self.direction.x*self.speed, old_rect)
        self.trymove('v', self.direction.y*self.speed, old_rect)

    def update(self):
        if self.health <= 0:
            self.player.points += 2 #increase 2 points only when the enemy is actually dead
            self.kill()


        dir = 'left'
        player_vector = math.Vector2(self.player.rect.center)
        enemy_vector = math.Vector2(self.rect.center)
        distance = player_vector.distance_to(enemy_vector)
        direction = (player_vector - enemy_vector)

        if self.player.rect.x > self.rect.x :
            dir = "right"
        else:
            dir = "left"

        if distance <= self.notice_r and distance >self.attack_r:
            self.move(direction)
        if distance <= self.attack_r and self.attack_timer<=0:
            self.attack_timer = self.shoot_projectile()
        
        self.animate(dir)
        if self.attack_timer > 0:
            self.attack_timer -= 1

        if hasattr(self.player, 'shield') and self.player.shield:
            shield_center = self.player.shield.rect.center
            enemy_center = self.rect.center

            dx = enemy_center[0] - shield_center[0] # since its enemy - shield it'll create a vector pointing from the SHIELD to the ENEMY (opp dir)
                                                    # if enemy is to the left, dx = -ve, which'll make it move more to the left, if enemy is to the right, dx = +ve, which'll make it move more to the right
            dy = enemy_center[1] - shield_center[1]
            distance = hypot(dx, dy)

            if distance < 100:
                # moves the enemy away from the shield along the vector pointing from the shield to the enemy
                direction = math.Vector2(dx, dy)
                if direction.length() > 0:
                    direction = direction.normalize()
                    self.rect.x += direction.x * self.speed
                    self.rect.y += direction.y * self.speed
                return  # stops normal movement like the projectile
            
    def shoot_projectile(self):
        fairy_sound = mixer.Sound('assets\\sounds\\mixkit-fast-magic-game-spell-883.wav')
        fairy_sound.play()
        direction = math.Vector2(self.player.rect.x, self.player.rect.y) - math.Vector2(self.rect.x, self.rect.y)
        if direction.length() != 0:
            direction = direction.normalize()
        else:
            direction = math.Vector2(0, 0)

        projectile = Projectile(self.rect.center, direction, 5, self.projectile_group, self.enemy_type, self.player, self)
        return projectile.cooldown

    def trymove(self,dir, val, old_rect):
        copy = sprite.Group() # i dont know why but copy = self.obstacles.copy() wasnt working so i had to add its sprites to copy using add
        copy.add(self.obstacles)
        copy.remove(self) # remove self from the copy and check if it collides with any other fairies
        
        if dir == "h":
            if sprite.spritecollideany(self, copy, sprite.collide_mask) == None:
                self.rect.x += val
                
            for spr in sprite.spritecollide(self, copy, False, sprite.collide_mask):
                
                if spr.sprite_type == 'enemy': #if two sprites overlap, move them a little so they dont overlap
                    offset = self.rect.centerx - spr.rect.centerx, self.rect.centery - spr.rect.centery
                    distance = hypot(*offset)
                    if distance < 32 and math.Vector2(offset).length != 0: #if distance between their centers is less than half a tile which means they're in the same tile
                        push_vector = math.Vector2(offset).normalize() * 5 
                        self.rect.x += push_vector.x 
                        self.rect.y += push_vector.y
                else:
                    self.rect.x += val

        if dir == "v":
            if sprite.spritecollideany(self, copy, sprite.collide_mask) == None:
                self.rect.y += val
            for spr in sprite.spritecollide(self, copy, False, sprite.collide_mask): 
                if spr.sprite_type == 'enemy': #if two sprites overlap, move them a little so they dont overlap
                    offset = self.rect.centerx - spr.rect.centerx, self.rect.centery - spr.rect.centery
                    distance = hypot(*offset)
                    if distance < 32 and math.Vector2(offset).length != 0: #if distance between their centers is less than half a tile which means they're in the same tile
                        push_vector = math.Vector2(offset).normalize() * 5 
                        self.rect.x += push_vector.x 
                        self.rect.y += push_vector.y
                else:
                    self.rect.y += val

