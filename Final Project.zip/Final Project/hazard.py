
from pygame import *
from settings import *

class Hazard(sprite.Sprite):
    def __init__(self, pos, groups, type, surface = surface.Surface((TILESIZE, TILESIZE))):
        super().__init__(groups) #adds the sprite to the given groups. 
        self.sprite_type = type #when creating the map, I gave each entity a certain class. enemy sprites under "enemy", gems under "collectible" etc
        self.current_sprite = 0.0
        self.image = surface
        self.rect = self.image.get_rect(topleft = pos)
        self.mask = mask.from_surface(self.image)
        self.animate()
        
    def animate(self):
        self.current_sprite += 0.15
        if self.current_sprite >= 3:
            self.current_sprite = 0
        self.image = image.load(f'levels//level_1//tilesets//hazards//plant_{int(self.current_sprite)}.png') #simple sprite animation. this is why i made a class for hazards and didnt just use tile
        self.mask = mask.from_surface(self.image)
    def update(self):
        self.animate()