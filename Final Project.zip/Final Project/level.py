from pygame import *
from player import Player
from map_loader import Map
from settings import *
from ui import UI


class Level:
    def __init__(self, screen):
        self.screen = screen
        #visible sprites is the only group that I'll draw on the screen. Obstacles are sprites that can collide with the player
        self.visible = Camera()
        self.obstacles = Camera()
        self.attackable = sprite.Group()
        self.hidden = sprite.Group()
        self.player = Player((490,240), [self.visible], self.obstacles)
        self.map = Map(self.visible, self.obstacles, self.player, self.attackable, self.hidden)
        self.ui = UI()


    def run(self):
        self.visible.draw(self.player)
        self.visible.update()
        self.hidden.update()
        self.player.collected.update()
        check_for_help = self.ui.display(self.player)
        if check_for_help == 'help':
            return 'help'
        return

class Camera(sprite.Group):
    def __init__(self):
        super().__init__()
        self.screen = display.get_surface()
        self.offset = math.Vector2()
        self.background = image.load('levels\\level_1\\level_data\\level1_background.png').convert()
        self.bg_rect = self.background.get_rect(topleft = (0,0))
        self.code_displayed = False
    
    def draw(self, player): #overwriting the inbuilt draw function
        #To create the illusion of a camera following the player, I add an offset to the position of the sprites surrounding the player based off the player's position
        #2528 = (64*40 => size of 1 tile x no. of horizontal tiles) - 64//2 (tilesize//2)
        if player.rect.x < 2528 - WIDTH//2: #right out of bounds
            self.offset.x = player.rect.centerx - (self.screen.get_width()//2) #to center the player amidst the camera
        #1888 = (64*20 => size of 1 tile x no. of horizontal tiles) - 64//2 (tilesize//2)
        if player.rect.y < 1888 - HEIGHT//2: #bottom out of bounds
            self.offset.y = player.rect.centery - (self.screen.get_height()//2)
        #create the background here so its always below the sprites

        if player.rect.x < WIDTH//2: #left. if the player moves left past half of the current screen, there's no offset otherwise we get a bit of the black screen
            self.offset.x = 0
        if player.rect.y < HEIGHT//2: #top
            self.offset.y = 0
            
        self.screen.blit(self.background, (self.bg_rect.topleft - self.offset))
        for sprite in self.sprites():
            offset_pos = sprite.rect.topleft - self.offset
            self.screen.blit(sprite.image, offset_pos)

        if hasattr(player, 'dark_overlay') and player.dark_overlay != None:
            player.dark_overlay.fill((0, 0, 0, 180))
            draw.circle(player.dark_overlay, (0, 0, 0, 0), player.rect.center- self.offset, 64) #circling the player and the objects with a transparent circle to give a flashlight effect
            for obj in player.hidden:
                draw.circle(player.dark_overlay, (0, 0, 0, 0), obj.rect.center - self.offset, 64) 
            self.screen.blit(player.dark_overlay, (0, 0))

        if hasattr(player, 'magic_code') and not self.code_displayed:
            dark_overlay = Surface(display.get_surface().get_size(), SRCALPHA)
            dark_overlay.fill((0,0,0,180))
            self.screen.blit(dark_overlay, (0,0))
            game_font = font.Font("assets\\screens\\Pixellari.ttf", 100)
            code = game_font.render(player.magic_code, True, 'white')
            code_rect = Rect(300,200, 150, 150)
            self.screen.blit(code, code_rect)
            display.flip()
            time.wait(5000) #displays the code for 5s on a dark background 
            self.code_displayed = True
            