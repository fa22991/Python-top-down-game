from pygame import *
from settings import *
import random
import string

class magic_object(sprite.Sprite):
    def __init__(self, pos, groups, type, surface = surface.Surface((TILESIZE, TILESIZE), SRCALPHA)):
        super().__init__(groups) #adds the sprite to the given groups. this is the only hidden layer
        self.sprite_type = 'magic_obj' #when creating the map, I gave each entity a certain class. enemy sprites under "enemy", gems under "collectible" etc
        self.magic_type = type
        self.image = surface
        self.rect = self.image.get_rect(topleft = pos)
        self.mask = mask.from_surface(self.image)
        self.collected = None
        self.collected_time = 0
        self.player = None
    
    def power_up(self, player):
        print('works')
        magic_sound = mixer.Sound('assets\\sounds\\diamond-found-190255.mp3')
        magic_sound.play()
        self.collected = self.magic_type
        self.player = player
        #only add the object if its not already collected, to prevent the effect from restarting 
        if self.magic_type == "potion" and 'potion' not in player.magic_objs :
            self.collected_time = time.get_ticks()
            player.spells.append('speed')
            player.speed += 5

        if self.magic_type == "amulet" and 'amulet' not in player.magic_objs:
            self.player.lives += 1  

        if self.magic_type == "key" and 'key' not in player.magic_objs:
            self.player.has_key = True  

        if self.magic_type == "cheese" and 'cheese' not in player.magic_objs:
            self.player.spells.append('special')

        if self.magic_type == "scroll" and 'scroll' not in player.magic_objs:
            self.player.magic_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=7)) #a random 7 character long string of uppercase letters and numbers
            print("Magic code received:", self.player.magic_code)


    def update(self):
        if self.collected == 'potion': #this is the only spell with a cooldown. i reset its effect once its over, which is in 10 seconds
            if time.get_ticks() - self.collected_time >= 10000:
                print(self.collected, 'over')
                self.player.speed = 7
                self.player.spells.remove('speed')
                self.collected = None
            