import sys, pygame
from pygame import *
from settings import *
from level import Level
import settings

'''
Game description/features : 
1. Map design using tiled, and import logic using the json module 
2. Modular code, broken down into classes and functions that can be reused for the most part
3. Sprite animations, sprite sheet loading functions and appropriate sound effects
4. Intro, help, success and failure screen with game-preserving logic 
5. UI design : visual indication of health and lives remaining, a countdown to the reveal spell, coins and point count etc
6. The reveal spell : reveals 5 magic objects (same locations, different objects at each one each time) that the player can collect. Notably, the key
   which unlocks the portal, and the scroll that gives you a magic code to enter at the end. 
   Integration of tkinter for user input. 
7. Enemy attack and movement logic using vectors. 'repulsion' effect from the player's shield, 'pushing' movement in case of overlap with each other, and a
   'resistance' that causes them to bounce back when hit, making them a harder target. 
8. Player movement using vectors. collision detection using mask collisions for accuracy. 
9. 2 Different types of attack - regular with less damage, special with more damage (see settings.py for more info)
10. Spell and attack cooldown logic using time.get_ticks()
11. Camera effect following the player using offsets. 
12. animated hazards that cause damage to the player. 
13. Storyline/world-building : a game 'mission' along with corresponding success and failure screens based off of the special 
    edition Geronimo Stilton books (kingdom of fantasy, the quest for paradise etc)
'''
#PLEASE RUN IT WITH LOW VOLUME THE MUSIC IS OBNOXIOUSLY LOUD
class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = time.Clock()
        self.level = Level(self.screen)
        self.in_intro = True
        self.was_playing = False
        self.sound_played = False
        mixer.music.load('assets//sounds//music.wav')
        

    def intro_screen(self, clicked):
        bg = transform.scale(image.load('assets//screens//bg.jpg'), (1000,500)) # did not design the bg
        banner = image.load('assets//screens//banner.png').convert_alpha() #i designed the banner, fun fact, I styled it exactly like the actual Geronimo stilton book title
        button = transform.scale(image.load('assets//screens//button.png'), (300, 50))
        self.screen.blit(bg, (0,0))
        self.screen.blit(banner, (0,50))
        self.screen.blit(button, (400,250))
        col_0 = "#312400"
        col_1 = "#312400"
        col_2 = "#312400"
        game_font = font.Font("assets\\screens\\Pixellari.ttf", 30)
        sb_rect = Rect(520,260, 150, 50)
        self.screen.blit(button, (400,310))
        h_rect = Rect(520,320, 150, 50)
        self.screen.blit(button, (400,370))
        q_rect = Rect(520,380, 150, 50)
        buttons = [q_rect, sb_rect, h_rect]
        l,m,r = mouse.get_pressed()
        pos = mouse.get_pos()
        if clicked: 
            for i, button in enumerate(buttons): 
                if button.collidepoint(pos):
                    if i == 0:
                        col_0 = "#966825"
                        return 'quit'
                    elif i == 1:
                        col_1 = "#966825"
                        return 'start'
                    else: 
                        col_2 = "#966825"
                        return "help"
        quit_button = game_font.render("Quit", True, col_0)
        start_button = game_font.render("Start", True, col_1)
        help_button = game_font.render("Help", True, col_2)
        self.screen.blit(start_button, sb_rect)
        self.screen.blit(help_button, h_rect)
        self.screen.blit(quit_button, q_rect)
        return None
    
    def show_help_screen(self,clicked):
        self.screen.fill('white')
        help = transform.scale(image.load('assets//screens//help screen.png'), (1000,500))
        self.screen.blit(help, (0,10))
        back = transform.scale(image.load('assets//screens//back.png'), (100,60))
        back_rect = self.screen.blit(back, (450,0))
        back.get_rect()
        pos = mouse.get_pos()
        if clicked:
            if back_rect.collidepoint(pos):
                return 'back'
        return 
    
    def success_failure_screen(self, clicked, img):
        
        bg = transform.scale(image.load(img), (1000,500)) # did not design the bg
        button = transform.scale(image.load('assets//screens//button.png'), (300, 50))
        self.screen.blit(bg, (0,0))
        self.screen.blit(button, (370,250))
        col_0 = "#312400"
        col_1 = "#312400"
        col_2 = "#312400"
        game_font = font.Font("assets\\screens\\Pixellari.ttf", 30)
        sb_rect = Rect(470,260, 150, 50)
        self.screen.blit(button, (370,310))
        h_rect = Rect(490,320, 150, 50)
        self.screen.blit(button, (370,370))
        q_rect = Rect(490,380, 150, 50)
        buttons = [q_rect, sb_rect, h_rect]
        l,m,r = mouse.get_pressed()
        pos = mouse.get_pos()
        if clicked: 
            for i, button in enumerate(buttons): 
                if button.collidepoint(pos):
                    if i == 0:
                        col_0 = "#966825"
                        return 'quit'
                    elif i == 1:
                        col_1 = "#966825"
                        return 'start'
                    else: 
                        col_2 = "#966825"
                        return "help"
        quit_button = game_font.render("Quit", True, col_0)
        start_button = game_font.render("Restart", True, col_1)
        help_button = game_font.render("Help", True, col_2)
        self.screen.blit(start_button, sb_rect)
        self.screen.blit(help_button, h_rect)
        self.screen.blit(quit_button, q_rect)
        return None
        
    def run(self):
        settings.clicked = False
        in_help = False
        
        while True:
            settings.clicked = False
            for evt in event.get():
                if evt.type == MOUSEBUTTONDOWN:
                    settings.clicked = True

                if evt.type == QUIT:
                    quit()
                    sys.exit()

            self.screen.fill("black")
            if self.in_intro:
                if not mixer.music.get_busy():
                    mixer.music.play(-1)
                action = self.intro_screen(settings.clicked)
                if action == "start":
                    self.in_intro = False
                    mixer.music.stop()
                elif action == "quit":
                    quit()
                    sys.exit()

                elif action == "help":
                    self.in_intro = False
                    in_help = True
                    mixer.music.stop()

            elif in_help:
                action = self.show_help_screen(settings.clicked)
                if action == 'back':
                    in_help = False
                    if self.was_playing:
                        self.was_playing = False  # reset it
                        # resume level
                        continue  # next loop will rerun whichever screen it was on 
                    else:
                        self.in_intro = True
            else:
                if settings.success: # im using settings.success instead of success because i dont want to check the local copy, i want to check the global copy in the actual file
                    action = self.success_failure_screen(settings.clicked, 'assets//screens//Success screen.png')
                    triumph = mixer.Sound('assets\\sounds\\11l-victory_trumpet-1749704469779-358762.mp3')
                    if self.sound_played == False:
                        triumph.play(1)
                        self.sound_played = True

                    if action == "start":
                        settings.success = False
                        self.level = Level(self.screen)
                        self.sound_played = False
                        self.in_intro = False

                    elif action == "quit":
                        quit()
                        sys.exit()

                    elif action == "help":
                        self.in_intro = False
                        self.was_playing = True
                        in_help = True

                elif settings.failure: # im using settings.failure instead of failure because i dont want to check the local copy, i want to check the global copy in the actual file
                    action = self.success_failure_screen(settings.clicked, 'assets//screens//Failure screen.png')
                    failure = mixer.Sound('assets\\sounds\\losing-horn-313723.mp3')
                    if self.sound_played == False:
                        failure.play(1)
                        self.sound_played = True
                    if action == "start":
                        settings.failure = False
                        self.level = Level(self.screen)
                        self.sound_played = False
                        self.in_intro = False
                    elif action == "quit":
                        quit()
                        sys.exit()
                    elif action == "help":
                        self.in_intro = False
                        in_help = True
                        self.was_playing = True
                else:
                    check_for_help = self.level.run()
                    if check_for_help == 'help':
                        self.was_playing = True
                        in_help = True

                
            pygame.display.update()
            self.clock.tick(FPS)


if __name__ == '__main__':
    game = Game()
    game.run()