from pygame import *
from player import Player
from tile import Tile
from enemy import Enemy
from settings import * 
from portal import Portal
from hazard import Hazard
import json 
from random import *
from magic import magic_object


class Map:
    def __init__(self, visible, obstacles, player, attackable, hidden):
        self.visible = visible
        self.obstacles = obstacles
        self.player = player
        self.attackable = attackable
        self.hidden = hidden
        self.player.hidden = self.hidden
        self.map = self.create_map()
        self.tileset = {}
        
    
    def format(self,data):
        #data from the level1_3.tmj file. I wrote a python function to format it into a 2d array of 60 rows and 40 columns as those are the dimensions of my map
        data_formatted = []
        c = 0
        for i in range(60):
            row = data[c:40+c]
            data_formatted.append(row)
            c += 40
        return data_formatted
        
    def image_path(self, path):
        return f"levels\\level_1\\tilesets\\{path.split('/')[2].split('.')[0]}.png"


    def create_tileset(self, data):
        tileset = {} 
        for tile in data:
            tileset[tile['firstgid']] = self.image_path(tile['source'])

        return tileset
    
        
    def create_map(self):
        magic =  ['key', 'amulet', 'potion', 'cheese', 'scroll']
        shuffle(magic)
        boundary = []
        collectible = []
        hazard = []
        enemy = []
        portal = []
        magic_obj = []

        with open('levels\\level_1\\level_data\\level1_3.tmj', 'r') as file:
            data = json.load(file)
            self.tileset = self.create_tileset(data['tilesets'])

            for layer in data['layers']:
                if layer['name'] == "Boundaries":
                    boundary = layer['data']
                if layer['name'] == "collectible":
                    collectible = layer['data']
                if layer['name'] == 'enemies':
                    enemy = layer['data']
                if layer['name'] == 'hazards':
                    hazard = layer['data']
                if layer['name'] == 'portal':
                    portal = layer['data']

        with open("levels\\level_1\\level_data\\level1_magicobjs.tmj") as file: #I forgot to create this layer when i was making the map and then I shifted my tilesets folder which deleted the map in tiled, 
            data = json.load(file)                                              #so I had to make a new one and export this layer seperately
            for layer in data['layers']:
                if layer['name'] == "magic_objects":
                    magic_obj = layer['data']

        layers = {
             'boundaries' : self.format(boundary),
             'collectibles' :   self.format(collectible),
             'enemies' :   self.format(enemy),
             'hazards' :   self.format(hazard),
             'portal' :   self.format(portal),
             'magic_objs' :   self.format(magic_obj)
            }
        #the following loop iterates over all the layers inside my map, and creates an instance of the appropriate class based
        #on what the layer contains. for example, the portal is an instance of the Portal class. 
        #based on whether or not i want them to show up on screen, i add them to the visible sprites group (self.visible) and all the obstacles
        #are in self.obstacles. 
        #enemies and their projectiles are also added to self.attackable which comes in handy when detecting collisions


        for layer, map in layers.items():
            for rind, row in enumerate(map):
                for cind, col in enumerate(row):
                    if col != 0:
                        i = 0
                        x = cind * TILESIZE
                        y = rind * TILESIZE
                        if layer == "boundaries":
                            if col in self.tileset.keys():
                                surf = image.load(f'{self.tileset[col]}').convert_alpha()
                                Tile((x,y), [self.visible, self.obstacles], 'boundary',surf) 
                        if layer == "collectibles":
                            if col in self.tileset.keys():
                                surf = image.load(f'{self.tileset[col]}').convert_alpha()
                                #y + 64-16 because the images are 16x16px not 64x64
                                Tile((x,y+52), [self.visible, self.obstacles], 'collectible',surf)
                        if layer == "hazards":
                            if col in self.tileset.keys():
                                surf = image.load(f'{self.tileset[col]}').convert_alpha()
                                #y + 64-16 because the images are 16x16px not 64x64
                                Hazard((x,y+32), [self.visible, self.obstacles], 'hazard',surf)
                        if layer == "enemies":
                            if col in self.tileset.keys():
                                #y + 64-16 because the images are 16x16px not 64x64
                                enemy = Enemy((x,y+52), [self.visible, self.obstacles, self.attackable], 'enemy',self.tileset[col], self.player, self.obstacles)
                                enemy.projectile_group = [self.visible, self.attackable]

                        if layer == "portal":
                            if col in self.tileset.keys():
                                surf = image.load(f'{self.tileset[col]}').convert_alpha()
                                #y + 64-16 because the images are 16x16px not 64x64
                                Portal((x,y+52), [self.visible, self.obstacles], 'portal',surf)

                        if layer == "magic_objs":
                            print(col)
                            surf = image.load(f'assets\\magic_objs\\{magic[col-1]}.png').convert_alpha()
                            #y + 64 because the images are 16x16px not 64x64
                            magic_object((x,y), [self.hidden], f'{magic[col-1]}',surf)
        
    