from pygame import *
from settings import *
import settings
import pygame
from sys import *
from tile import Tile
from random import *
import tkinter as tk
from tkinter import simpledialog

#The player class is set to inherit from the sprite class instead of rect because 
# 1. you can group sprites together, so I can have a player, then a group of enemies etc
# 2. you can use the draw function to draw a sprite on the screen
# 3. Because the player is technically a sprite not a rect
attacked = False
class Player(sprite.Sprite):
    def __init__(self, pos, groups, obstacles):
        super().__init__(groups)
        self.sprite = self.load_images()
        self.current_sprite = 0.0
        self.animate = False
        self.current_state = "r"
        self.image = self.sprite["idle_"+self.current_state]
        self.rect = self.image.get_rect(topleft = pos)
        #the idea for using a vector wasnt mine but i do know how and why it works
        self.direction = math.Vector2() #x and y position of player as a vector. keyboard input will change these values
        self.obstacles = obstacles
        self.mask = mask.from_surface(self.image)
        self.coins = 0
        self.points = 0
        self.is_attacking = False
        self.attack_time = None
        self.weapon = "attack"
        self.current_spell = None
        self.cast_time = 0
        self.can_cast_again = True
        self.target = None
        self.collected = sprite.Group()
        #UI healthbar
        self.condition = {'health' : 100, 'energy' : 100, 'attack' : 10, 'spells' : 1, 'weapons' : 1, 'speed' : 7, 'lives' : 3}
        self.health = self.condition['health']
        self.energy = self.condition['energy']
        self.spells = ['regular']
        self.speed = self.condition['speed']
        self.lives = self.condition['lives']
        self.magic_objs = []
        self.reveal_timer = 0

    def load_sprite_sheet(self, path, frame_width, frame_height):
        sheet = image.load(path).convert_alpha()
        sw, sh = sheet.get_size()

        sprites = []
        for y in range(0, sh, frame_height):
            for x in range(0, sw, frame_width):
                frame = Surface((frame_width, frame_height), SRCALPHA)
                frame.blit(sheet, (0, 0), (x, y, frame_width, frame_height)) #blit different parts of the spritesheet 
                sprites.append(frame)

        return sprites
    
    def load_images(self):
        states = {}
        run_right = self.load_sprite_sheet('assets//sprites//level_1_mc//running.png', 64, 64)
        run_left = [transform.flip(img, True, False) for img in run_right]
        run_up = [transform.rotate(img, 90) for img in run_right]
        run_down = [transform.rotate(img, -90) for img in run_right]
        attack_r =  self.load_sprite_sheet('assets//sprites//level_1_mc//attack.png', 64,64)
        attack_u = [transform.rotate(img, 90) for img in attack_r]
        attack_d  = [transform.rotate(img, -90) for img in attack_r]
        attack_l = [transform.flip(img, True, False) for img in attack_r]
        special_r = self.load_sprite_sheet('assets//sprites//level_1_mc//special_2.png', 64, 64)
        special_l = [transform.flip(img, True, False) for img in special_r]
        special_u = [transform.rotate(img, 90) for img in special_r]
        special_d = [transform.rotate(img, -90) for img in special_r]

        states['running_l'], states['running_r'],states['running_u'], states['running_d'] = run_left, run_right, run_up, run_down
        states['idle_r'] = image.load(f'assets//sprites//level_1_mc//idle.png').convert_alpha()
        states['idle_l'], states['idle_u'], states['idle_d'] = transform.flip(states['idle_r'], True, False), transform.rotate(states['idle_r'], 90), transform.rotate(states['idle_r'], -90)
        states['attack_r'], states['attack_l'], states['attack_u'], states['attack_d'] = attack_r, attack_l, attack_u, attack_d
        states['special_r'], states['special_l'], states['special_u'], states['special_d'] = special_r, special_l, special_u, special_d
        
        return states
    
    def input(self):
        self.animate = False
        keys = key.get_pressed()
        if keys[K_RIGHT]: 
            self.direction.x = 1
            self.current_state = "r"
            self.animate = True
            
        elif keys[K_LEFT]:
            self.direction.x = -1 
            self.current_state = "l"
            self.animate = True
        else:
            self.direction.x = 0
            

        if keys[K_UP]:
            self.direction.y = -1 
            self.current_state = "u"
            self.animate = True
        elif keys[K_DOWN]:
            self.direction.y = 1 
            self.current_state = "d"
            self.animate = True
        else:
            self.direction.y = 0
        
        if keys[K_a]:
            self.is_attacking = True
            self.weapon = "attack"
            self.attack_time = time.get_ticks()

        if keys[K_c] and 'special' in self.spells: #unlock special weapon if the player has collected at least 30 coins. only this special weapon can kill the ending fairies
            self.is_attacking = True
            self.weapon = "special"
            self.attack_time = time.get_ticks()
        

    def move(self):
        old_rect = self.rect.copy() #store the prev positions incase i need to undo a move in collision
        #When we press both up/down and right/left keys together, the player moves significantly faster. 
        #Here, I check if the vector has a magnitude, which is possible if there is movement in both the axis. 
        #If there is, I normalize the vector to have a magnitude of 1 so that speed in that direction stays the same as the speed moving only horizontally or vertically
        if self.direction.magnitude() != 0: 
            self.direction = self.direction.normalize()
        self.rect.x += self.direction.x * self.speed
        self.collision("horizontal", old_rect) #check for horizontal collisions when moving on the x axis so we dont accidently reverse the y move
        self.rect.y += self.direction.y * self.speed
        self.collision("vertical", old_rect) #check for vertical collisions when moving on the y axis so we dont accidently reverse the x move 
    
    def animate_player(self):
        direction = self.current_state
        
        if self.animate:
            if self.is_attacking:
                animation = self.sprite[self.weapon+"_" + direction]
                self.current_sprite += 0.15
                if self.current_sprite >= len(animation):
                    self.current_sprite = 0
                self.image = animation[int(self.current_sprite)]
            else:
                animation = self.sprite['running_' + direction]
                self.current_sprite += 0.15
                if self.current_sprite >= len(animation):
                    self.current_sprite = 0
                self.image = animation[int(self.current_sprite)]
        else:
            if self.is_attacking:
                animation = self.sprite[self.weapon+"_" + direction]
                self.current_sprite += 0.15
                if self.current_sprite >= len(animation):
                    self.current_sprite = 0
                self.image = animation[int(self.current_sprite)]
            else:
                self.image = self.sprite['idle_' + direction]
        
        self.mask = mask.from_surface(self.image)
        self.rect = self.image.get_rect(center=self.rect.center)


    def update(self):
        global attacked 
        self.input()
        self.move()
        if self.is_attacking:
            attacked = True
            self.attack(self.obstacles)
            if time.get_ticks() - self.attack_time > 360: #360s is the cooldown
                self.is_attacking = False
                arrow_sound = mixer.Sound('assets\\sounds\\arrow-swish_03-306040.mp3')
                arrow_sound.play()
        # if self.is_attacking and self.weapon == "special":
        #     self.attack(self.obstacles)
        #     if time.get_ticks() - self.attack_time > 60000:
        #         self.weapon = "attack"
        #         self.points = 0
        # if attacked: 
        #     arrow_sound = mixer.Sound('assets\\sounds\\arrow-swish_03-306040.mp3')
        #     arrow_sound.play()
        #     attacked = False
        self.animate_player()

        if self.health <= 0:
            self.lives -= 1
            self.health = 100

        self.cast_spell()

        if self.current_spell == 'shield_circle' and hasattr(self, 'shield'):
            self.shield.rect.center = self.rect.center

        if self.current_spell:
            if time.get_ticks() - self.cast_time >= protection[current_level][self.current_spell]['lasts_for']:
                if self.current_spell == 'shield_circle': #once the shield circle is over i kill the shield
                    self.shield.kill()
                elif self.current_spell == 'reveal':
                    self.cast_time = time.get_ticks()
                    self.can_cast_again = False
                    for spr in self.hidden:
                        self.groups()[0].remove(spr)
                        self.obstacles.remove(spr)
                    self.dark_overlay = None
                    
                self.current_spell = None
                self.coins = 0 #resets the coin count each time so i can activate the shield again and again when the criteria is met
                print('over')


        if time.get_ticks() - self.cast_time >= protection[current_level]['reveal']['cooldown']:
            self.can_cast_again = True #after 24 seconds

        if self.lives <= 0:
            settings.failure = True #display failure screen

        
    
    def attack(self, enemies):
        direction = self.current_state
        attack_range = 100
        target_enemy = None

        for enemy in enemies:
            if enemy.sprite_type == "enemy":
                dx = enemy.rect.centerx - self.rect.centerx
                dy = enemy.rect.centery - self.rect.centery

                if direction == "r" and 0 <= dx <= attack_range and abs(dy) < 32: #chooses the enemy in the most appropriate direction, right, left, top or down
                    target_enemy = enemy

                elif direction == "l" and -attack_range <= dx <= 0 and abs(dy) < 32:
                    target_enemy = enemy

                elif direction == "u" and -attack_range <= dy <= 0 and abs(dx) < 32:
                    target_enemy = enemy

                elif direction == "d" and 0 <= dy <= attack_range and abs(dx) < 32:
                    target_enemy = enemy

                if target_enemy:
                    break  # only one enemy

        if target_enemy:
            self.target = target_enemy
            target_enemy.rect.x += target_enemy.resistance
            target_enemy.rect.y += target_enemy.resistance
            target_enemy.health -= attack_data[self.weapon]['damage']  
            print(target_enemy.health)

    def cast_spell(self):
        keys = key.get_pressed()
        if keys[K_r] and self.current_spell == None and self.can_cast_again:
            self.current_spell = "reveal"
            self.cast_time = time.get_ticks()
            if hasattr(self, 'hidden'):
                for spr in self.hidden:
                    self.groups()[0].add(spr)
                    self.obstacles.add(spr)
            self.dark_overlay = pygame.Surface(display.get_surface().get_size(), pygame.SRCALPHA)

        if self.coins >= 25 and self.current_spell == None:
            self.cast_time = time.get_ticks()
            self.current_spell = 'shield_circle'
            shield_img = transform.scale(image.load('assets//sprites//level_1_mc//shield_circle.png'), (100,100))
            self.shield = Tile((self.rect.centerx, self.rect.centery), [self.groups()[0], self.obstacles], 'protection', shield_img) 

        #self.groups()[0] is just visible sprites. i add it to visible sprites when its active and remove it by killing it when not

    def collision(self,dir, old_rect):
        
        # if dir == 'horizontal':
        #     for sprite in self.obstacles:
        #         if sprite.rect.colliderect(self.rect):
        #             if self.direction.x > 0: #if you're moving right, collisions will happen towards the right
        #                 self.rect.right = sprite.rect.left #if the player encounters a boundary, set its right to the boundary's left so it cannot go past it   
        #             elif self.direction.x < 0:
        #                 self.rect.left = sprite.rect.right

        # if dir == 'vertical':
        #     for sprite in self.obstacles:
        #         if sprite.rect.colliderect(self.rect):
        #             if self.direction.y > 0: #if you're moving down, collisions will happen towards the bottom
        #                 self.rect.bottom = sprite.rect.top #if the player encounters a boundary, set its right to the boundary's left so it cannot go past it   
        #             elif self.direction.y < 0:
        #                 self.rect.top = sprite.rect.bottom

        #I switched from using regular rect collisions to mask collisions because in my tilemap, the obstacles are more than 64 pixels and take up more than 1 tile.
        #however not all of these tiles are completely occupied by the object and there is some space left. So when i check for rect collisions, the player can collide with the empty space too
        #I dont want that to happen so i check for mask collisions which are more precise, as they check the collision between the pixels occupied by the image
        if dir == 'horizontal':
            for sprite in self.obstacles:
                if self.mask.overlap(sprite.mask, (sprite.rect.x - self.rect.x, sprite.rect.y - self.rect.y)):
                    self.rect.x = old_rect.x #undo the move
                    if sprite.sprite_type == 'collectible':
                        sprite.kill() 
                        self.coins += 1
                        self.points += 1
                        coin_sound = mixer.Sound('assets\\sounds\\retro-coin-4-236671.mp3')
                        coin_sound.play()
                    if sprite.sprite_type == 'magic_obj':
                        sprite.power_up(self)
                        sprite.kill() # i realized that if i killed the obj to remove it from the screen, that would mean removing it from all groups, which would mean that it didnt get updated so the cooldown wouldnt work
                                        #instead i add it to a group call collected and update that group in my level class
                        self.collected.add(sprite)
                        self.magic_objs.append(sprite.magic_type)
                        self.points += 5
                    if sprite.sprite_type == "hazard" and self.current_spell!='shield_circle':
                        time.wait(400)
                        hurt_sound = mixer.Sound('assets\\sounds\\retro-hurt-2-236675.mp3')
                        hurt_sound.play()
                        self.health -= 30
                        print(self.health)

                    if sprite.sprite_type == "portal":
                        if 'key' in self.magic_objs:
                            entered_code = self.get_code_from_user()
                            if entered_code == self.magic_code:
                                settings.success = True
                                print("Portal unlocked")
                            else:
                                print("Wrong code")
                                settings.failure = True
                        
        
        if dir == 'vertical':
            for sprite in self.obstacles:
                if self.mask.overlap(sprite.mask, (sprite.rect.x - self.rect.x, sprite.rect.y - self.rect.y)):
                    self.rect.y = old_rect.y  #undo the move       
                    if sprite.sprite_type == 'collectible':
                        sprite.kill()
                        self.coins += 1
                        self.points += 1
                        coin_sound = mixer.Sound('assets\\sounds\\retro-coin-4-236671.mp3')
                        coin_sound.play()

                    if sprite.sprite_type == 'magic_obj':
                        sprite.power_up(self)
                        sprite.kill()
                        self.collected.add(sprite)
                        self.magic_objs.append(sprite.magic_type)
                        self.points += 5

                    if sprite.sprite_type == "hazard" and self.current_spell!='shield_circle':
                        time.wait(400)
                        self.health -= 30
                        hurt_sound = mixer.Sound('assets\\sounds\\retro-hurt-2-236675.mp3')
                        hurt_sound.play()
                        print(self.health)

                    if sprite.sprite_type == "portal":
                        if 'key' in self.magic_objs:
                            entered_code = self.get_code_from_user()
                            if entered_code == self.magic_code:
                                settings.success = True 
                                print("Portal unlocked")
                            else:
                                print("Wrong code")
                                settings.failure = True
                            


    def get_code_from_user(self):

        root = tk.Tk()
        root.withdraw()

        code = simpledialog.askstring("Magic Code", "Enter the 7-character code:") #the random code generated when they collect the scroll

        root.destroy()

        return code.upper() if code else None

        
        
                        

