from pygame import *
from settings import *

#basically the same as hazard
class Portal(sprite.Sprite):
    def __init__(self, pos, groups, type, surface = surface.Surface((TILESIZE, TILESIZE))):
        super().__init__(groups) #adds the sprite to the given groups.
        self.sprite_type = type #when creating the map, I gave each entity a certain class. enemy sprites under "enemy", gems under "collectible" etc
        self.image = surface
        self.rect = self.image.get_rect(topleft = pos)
        self.mask = mask.from_surface(self.image)
        self.collected = None
        self.current_sprite = 0
    
    def load_sprite_sheet(self, path, frame_width, frame_height):
        sheet = image.load(path).convert_alpha()
        sw, sh = sheet.get_size()

        sprites = []
        for y in range(0, sh, frame_height):
            for x in range(0, sw, frame_width):
                frame = Surface((frame_width, frame_height), SRCALPHA)
                frame.blit(sheet, (0, 0), (x, y, frame_width, frame_height)) #blit different parts of the spritesheet 
                sprites.append(frame)

        return sprites
    
    def animate(self):
        sprites = self.load_sprite_sheet('levels//level_1//tilesets//portal.png', 72, 154)
        self.current_sprite += 0.15
        if self.current_sprite >= 3:
            self.current_sprite = 0
        self.image = sprites[int(self.current_sprite)]
        self.mask = mask.from_surface(self.image)

    def update(self):
        self.animate()