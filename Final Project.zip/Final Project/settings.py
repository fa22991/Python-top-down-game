
WIDTH = 1000
HEIGHT = 500
FPS = 60
TILESIZE = 64
current_level = 'Level 1'
is_alive = True
success = False
failure = False

enemy_data = {
    'Fairy 1' : {'health': 100, 'damage': 5, 'attack_r' : 100, 'notice_r' : 200, 'resistance' : 10, 'speed':5, 'cooldown' : 80},
    'Fairy 2' : {'health': 100, 'damage': 3, 'attack_r' : 80,'notice_r' : 300, 'resistance' : 25, 'speed': 8, 'cooldown' : 50},
    'Fairy 3' : {'health': 100, 'damage': 10, 'attack_r' : 50, 'notice_r' : 100, 'resistance' : 30,'speed': 6, 'cooldown' : 100}
}
attack_data = {
    'attack' : {'damage':30},
    'special' : {'damage': 50},
    'special_2' : {'damage': 100}
}
protection = {
    'Level 1':{
        'shield_circle' : {'lasts_for' : 8000, 'cooldown' : 300},
        'reveal' : {'lasts_for' : 12000, 'cooldown' : 24000}
        }
}
h_width = 200
h_height = 20
clicked = False