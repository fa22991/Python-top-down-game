from pygame import *
from math import *
from settings import *
import glob

class Projectile(sprite.Sprite):
    def __init__(self, pos, direction, speed, groups, enemy_type, player, enemy_that_shot_projectile):
        super().__init__(groups)
        self.sprite_type = "projectile"
        self.enemy_type = enemy_type
        self.image = Surface((10, 10), SRCALPHA)
        self.rect = self.image.get_rect(center=pos)
        self.mask = mask.from_surface(self.image)
        self.cooldown = enemy_data[enemy_type]['cooldown']
        self.direction = direction.normalize()
        self.speed = enemy_data[self.enemy_type]['speed']
        self.lifetime = 30  # Frames until it disappears so like 1/2s frame at 60 FPS
        self.screen = display.get_surface()
        self.current_sprite = 0
        self.player = player
        self.attackable = groups[1]
        self.enemy_that_shot_projectile = enemy_that_shot_projectile
    
    
    def animate(self):
        sprites = glob.glob(f"assets//sprites//{self.enemy_type}_attack//*.png") #the folders are named in this format making it easier to select the images for each enemy type
        self.current_sprite += 0.15
        if self.current_sprite > len(sprites):
            self.current_sprite = 0
        self.image = image.load(sprites[int(self.current_sprite)])
        self.mask = mask.from_surface(self.image)
        
        

    def update(self):
        self.animate()
        self.rect.x += self.direction.x * self.speed
        self.rect.y += (self.direction.y * self.speed)
        self.lifetime -= 1
        if self.lifetime <= 0:
            self.kill()
        if hasattr(self.player, 'shield') and self.player.shield != None:               
            if self.mask.overlap(self.player.shield.mask, (self.player.shield.rect.x - self.rect.x, self.player.shield.rect.y - self.rect.y)):
                self.kill()                         #offset is how far the masks are away from each other 
        if self.mask.overlap(self.player.mask, (self.player.rect.x - self.rect.x, self.player.rect.y - self.rect.y)):
            if self.player.target == self.enemy_that_shot_projectile and self.player.is_attacking:
                self.kill() #shot disappears if it hits the player
            else:
                self.player.health -= enemy_data[self.enemy_type]['damage'] #player only takes damage if he doesnt hit the projectile coming from the target enemy
                self.kill() #shot disappears if it hits the player

