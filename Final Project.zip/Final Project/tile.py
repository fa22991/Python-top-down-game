from pygame import *
from settings import *

class Tile(sprite.Sprite):
    def __init__(self, pos, groups, type, surface = surface.Surface((TILESIZE, TILESIZE), SRCALPHA)):
        super().__init__(groups) #adds the sprite to the given groups. 
        self.sprite_type = type #when creating the map, I gave each entity a certain class. enemy sprites under "enemy", gems under "collectible" etc
        self.image = surface
        self.rect = self.image.get_rect(topleft = pos)
        self.mask = mask.from_surface(self.image)
        
    