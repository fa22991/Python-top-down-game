from pygame import *
from settings import *
import settings

class UI:
    def __init__(self):
        self.screen = display.get_surface()
        self.font = font.Font('assets//screens//Pixellari.ttf', 20)
        self.health_bar = Rect(115,10, h_width, h_height)
        self.h_col = "#F3E73F"


    def display(self, player):
        dark_overlay = Surface((350,220), SRCALPHA)
        dark_overlay.fill((0,0,0,100))
        self.screen.blit(dark_overlay, (0,0))
        #health rect
        bg_rect = draw.rect(self.screen, "#7E7E7E", self.health_bar)
        current_health = 2*player.health
        current_rect = bg_rect.copy()
        current_rect.width = current_health
        health = self.font.render('Health', True,  '#ffffff')
        ht_rect = Rect(40,10,25,25)
        self.screen.blit(health, ht_rect)
        draw.rect(self.screen, 'red',current_rect )
        draw.rect(self.screen, 'black',bg_rect,2 )

        #lives rect
        lives = self.font.render('Lives', True,   '#ffffff')
        l_rect = Rect(40,40,25,25)
        self.screen.blit(lives, l_rect)
        heart = transform.scale(image.load('assets//screens//heart.png'), (20,20))
        for i in range(player.lives):
            self.screen.blit(heart, (110+i*40, 40))

        #current spell
        spell = self.font.render('Current Spell', True,   '#ffffff')
        s_rect = Rect(40,70,25,25)
        self.screen.blit(spell, s_rect)
        current_spell = self.font.render(player.current_spell, True,  "#007185")
        cs_rect = Rect(180,70,25,25)
        self.screen.blit(current_spell, cs_rect)

        #reveal countdown
        reveal = self.font.render('Reveal countdown', True,   '#ffffff')
        r_rect = Rect(40,100,25,25)
        self.screen.blit(reveal, r_rect)
        if player.current_spell != "reveal" and player.can_cast_again != True:
            reveal_spell = self.font.render(f'{24-(time.get_ticks() - player.cast_time)//1000}', True,  "#E393FC")
        elif player.current_spell != "reveal" and player.can_cast_again:
            reveal_spell = self.font.render(f'RECHARGED', True,  "#5A9FEE")
        elif player.current_spell == 'reveal':
            reveal_spell = self.font.render(f'ACTIVE', True,  "#5A9FEE")

        rs_rect = Rect(210,100,25,25)
        self.screen.blit(reveal_spell, rs_rect)

        #assets
        assets = self.font.render('Assets', True,   '#ffffff')
        a_rect = Rect(40,130,25,25)
        self.screen.blit(assets, a_rect)
        curr_assets = []
        asset_rects = []
        for i, spell in enumerate(player.spells):
            curr_assets.append(self.font.render(spell, True,  "#F1AB68"))
            asset_rects.append(Rect(120 + i*80,130,25,25))
        
        for spell, rect in zip(curr_assets, asset_rects):
            self.screen.blit(spell, rect)

        #objects collected 
        objs = self.font.render('Objects', True,   '#ffffff')
        o_rect = Rect(40,160,25,25)
        self.screen.blit(objs, o_rect)
        curr_objs = []
        obj_rects = []
        for i, obj in enumerate(player.magic_objs[:3]):
            curr_objs.append(self.font.render(obj, True,  "#68F1B8"))
            obj_rects.append(Rect(120 + i*80,160,25,25))
        if len(player.magic_objs)>3:
            for i, obj in enumerate(player.magic_objs[3:]):
                curr_objs.append(self.font.render(obj, True,  "#68F1B8"))
                obj_rects.append(Rect(120 + i*80,190,25,25))
        
        for obj, rect in zip(curr_objs, obj_rects):
            self.screen.blit(obj, rect)

        #coins and points 
        coins = self.font.render('Coins', True,   "#FFFFFF")
        coin_rect = Rect(880,10,25,25)
        self.screen.blit(coins, coin_rect)
        curr_coins = self.font.render(f'{player.coins}', True,  "#F1EF42")
        cc_rect = Rect(940,10,25,25)
        self.screen.blit(curr_coins, cc_rect)
        points = self.font.render('Points', True,   "#FFFFFF")
        point_rect = Rect(880,40,25,25)
        self.screen.blit(points, point_rect)
        curr_points = self.font.render(f'{player.points}', True,  "#F7A25D")
        cp_rect = Rect(940,40,25,25)
        self.screen.blit(curr_points, cp_rect)

        #help button
        button = transform.scale(image.load('assets//screens//button.png'), (100, 30))
        help_button = self.font.render("Help", True, 'white')
        h_rect = Rect(900,75, 100, 20)
        self.screen.blit(button, (870,70))
        self.screen.blit(help_button, h_rect)
        pos = mouse.get_pos()
        if settings.clicked:
            if h_rect.collidepoint(pos):
                return 'help'
        return